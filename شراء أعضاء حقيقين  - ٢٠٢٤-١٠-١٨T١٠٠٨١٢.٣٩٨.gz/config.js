module.exports = {
  bot: {
    owners: ["764180361559146556"],  // اونر
    botID: "1273392784421949461",    // ايدي البوت
    GuildId: "1157242460527931432",   // ايدي السيرفير
    ClientId: "1273392784421949461",    // ايدي البوت
    serverinvte: "https://discord.com/invite/sQU4DujM7d", // انفايت سير
    clientSECRET: "kgTOKM3uRYSWmZVRiXl6s3nRqBmX92xQ", // سكريت
    callbackURL: "http://fi6.bot-hosting.net:22878/login", // الكال باك
    TheLinkVerfy : 'https://discord.com/oauth2/authorize?client_id=1273392784421949461&response_type=code&redirect_uri=http%3A%2F%2Ffi6.bot-hosting.net%3A22878%2Flogin&scope=email+identify+guilds+guilds.join', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '$', 
     TOKEN: ("MTI3MzM5Mjc4NDQyMTk0OTQ2MQ.GWdb0u.M6ChlExlp0vkwYtQSAnbpaRrksR83kMlYUKzcY"),// توكن 
    TraId  : '1122017955966877776', // الي يتحوله كريديت
    done : "1274851683423359067",//ايدي روم تمت العملية
    line : "https://cdn.discordapp.com/attachments/1266538884330819584/1266540702045835337/Design_sans_titre.gif?ex=66a58572&is=66a433f2&hm=f6723336d04400fb9f27e18a3e14f4dc3384df9931221e6f6c7dfa9a2387fb97&",//رابط خط السيرفر
    stockimg : "https://cdn.discordapp.com/attachments/1266538884330819584/1266540702045835337/Design_sans_titre.gif?ex=66a58572&is=66a433f2&hm=f6723336d04400fb9f27e18a3e14f4dc3384df9931221e6f6c7dfa9a2387fb97&",//رابط صوره ستوك الاعضاء
      supportimg : "https://cdn.discordapp.com/attachments/1266538884330819584/1266540702045835337/Design_sans_titre.gif?ex=66a58572&is=66a433f2&hm=f6723336d04400fb9f27e18a3e14f4dc3384df9931221e6f6c7dfa9a2387fb97&",//رابط صوره تذكرة الدعم الفني
    ticketimg : "https://cdn.discordapp.com/attachments/1266538884330819584/1266540702045835337/Design_sans_titre.gif?ex=66a58572&is=66a433f2&hm=f6723336d04400fb9f27e18a3e14f4dc3384df9931221e6f6c7dfa9a2387fb97&",//زابط صور تذكرة الشراء
    fedroom : "",//ايدي روم الفيدباك
    clientrole : "1249503150222610533"//ايدي رتبه الزباين
  },
  website: {
    PORT: "3001",
  }
}